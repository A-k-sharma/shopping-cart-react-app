import React, { Component } from "react";
import uuid from "uuid";

export default class AddItem extends Component {
  state = {
    item: {
      name: "",
      quantity: 0,
      price: 0,
      index: uuid()
    }
  };
  handldeChange = event => {
    let newItem = {};
    let formInput = event.target.value.split("-");
    newItem.name = formInput[0];
    newItem.price = formInput[1];
    newItem.quantity = 1;
    newItem.total = newItem.price * newItem.qty;
    newItem.index = uuid();
    this.setState({
      item: newItem
    });
  };
  render() {
    return (
      <form onSubmit={e => this.props.handleAdd(e, this.state.item)}>
        <input
          onChange={this.handldeChange}
          type="text"
          name="name"
          className="textfield"
          placeholder="Enter item and price separated by a - (hyphen)"
        />
      </form>
    );
  }
}
