import React, { Component } from "react";

export default class Item extends Component {
  render() {
    const { item, index } = this.props;
    return (
      <tr>
        <td>{item.name}</td>
        <td>{item.quantity}</td>
        <td>{item.price}</td>
        <td>{item.quantity * item.price}</td>
        <td>
          <button
            className={"btn"}
            type="button"
            onClick={() => this.props.add(item.index)}
          >
            +
          </button>
        </td>
        <td>
          <button
            className={"btn"}
            type="button"
            onClick={() => this.props.minus(item.index)}
          >
            -
          </button>
        </td>
        <td>
          <button
            className={"btn"}
            type="button"
            onClick={() => this.props.del(item.index)}
          >
            Del
          </button>
        </td>
      </tr>
    );
  }
}
