import React, { Component } from "react";
import Item from "./item";
import AddItem from "./additem";
import uuid from "uuid";
export default class Cart extends Component {
  constructor() {
    super();
    this.state = {
      item: [
        {
          name: "Mango",
          quantity: 1,
          price: 50,
          index: uuid()
        },
        {
          name: "Orange",
          quantity: 1,
          price: 50,
          index: uuid()
        }
      ]
    };
  }

  inc = index => {
    const newItems = this.state.item.map(element => {
      if (element.index === index) {
        element.quantity = element.quantity + 1;
        return element;
      }
      return element;
    });
    this.setState({
      item: newItems
    });
  };

  dec = index => {
    const newItems = this.state.item.map(element => {
      if (element.index === index) {
        element.quantity = element.quantity - 1;
        return element;
      }
      return element;
    });
    this.setState({
      item: newItems
    });
  };

  delete = index => {
    const newItems = this.state.item.filter(element => {
      if (element.index !== index) {
        return element;
      }
    });
    this.setState({
      item: newItems
    });
  };

  handleAdd = (event, item) => {
    event.preventDefault();
    let flag = 0;
    this.state.item.forEach(i => {
      if (i.name === item.name) {
        alert("this item already exists");
        flag = 1;
      }
    });
    if (!flag) {
      this.state.item.push(item);
      this.setState({
        item: this.state.item
      });
    }
  };
  render() {
    return (
      <div className="cart">
        <table>
          <tr>
            <th>Items</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
            <th>INC</th>
            <th>DEC</th>
            <th>Delete</th>
          </tr>
          {this.state.item.map((item, index) => (
            <Item
              item={item}
              key={index}
              add={this.inc}
              minus={this.dec}
              del={this.delete}
            />
          ))}
        </table>
        <h3>Add Item</h3>
        <AddItem
          handleOnChange={this.handleOnChange}
          handleAdd={this.handleAdd}
        />
      </div>
    );
  }
}
