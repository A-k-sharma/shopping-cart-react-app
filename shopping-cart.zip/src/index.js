import React, { Component } from "react";
import ReactDOM from "react-dom";
import Cart from "./component/cart";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div className="App">
        <h1>My Cart</h1>
        <Cart />
      </div>
    );
  }
}

export default App;
const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
